#feature-id    PiMagic : Utilities > PiMagic
#feature-info  A post-integration pipeline script for PixInsight.

// ==================== CROSS-PLATFORM CONFIG ====================
var DEFAULT_INPUT_DIR  = File.homeDirectory + "/Desktop/Astrophotography/Input";
var DEFAULT_OUTPUT_DIR = File.homeDirectory + "/Desktop/Astrophotography/Output";
var SUPPORTED_EXTENSIONS = [ ".xisf", ".fit", ".fits", ".tif", ".tiff" ];

// Suppress ImageSolver dialog (remove this line if you want the window back)
// var ImageSolverDoNotShowDialog = true;

// ==================== PJSR HEADERS ====================
#include <pjsr/Sizer.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/DataType.jsh>

// ==================== CORE SCRIPT DEPENDENCIES ====================
// Script resides in <PixInsight>/src/scripts/, so use quoted relative paths:
/* #include "AdP/ImageSolver.js"
#include "Toolbox/GraXpertLib.jsh"

// ==================== SHELL MAPPING ====================
#ifdef __PI_PLATFORM__MACOSX
  #define CMD_EXEC "/bin/sh"
  #define SCRIPT_EXT ".sh"
#endif
#ifdef __PI_PLATFORM__MSWINDOWS
  #define CMD_EXEC "cmd.exe"
  #define SCRIPT_EXT ".bat"
#endif
#ifdef __PI_PLATFORM__LINUX
  #define CMD_EXEC "/bin/sh"
  #define SCRIPT_EXT ".sh"
#endif */
// ==================== CORE SCRIPT DEPENDENCIES ====================
// Quoted, relative to THIS file (because you're in <PixInsight>/src/scripts/)
#include "AdP/ImageSolver.js"
#include "Toolbox/GraXpertLib.jsh"
// (Optional) Defensive check: if either include was missing in an unusual install,
// the compiler would already stop here. Nothing else needed at runtime.

// Dynamically load scripts for cross-platform compatibility
// var scriptBasePath = File.cleanPath( CoreApplication.applicationDirPath + "/../src/scripts/" );


(function(){

// -------------------- Configuration & Globals --------------------
var DEBUG_MODE = true;
var INTERACTIVE_MODE = false;  // Main interactive mode is off for automation. Pauses are handled separately.
var debugStepCounter = 1;
var USER_ABORTED = false;

// Custom Error Types for Flow Control
const ABORT_PROCESSING = "ABORT_PROCESSING"; // Stop the entire batch
const ABORT_PROCESSING_IMAGE = "ABORT_PROCESSING_IMAGE"; // Stop current image, continue batch

var outputExtension = ".xisf";
var defaults = {
  displayEachStep:  false,
  inputDir:  DEFAULT_INPUT_DIR,
  outputDir: DEFAULT_OUTPUT_DIR,
  processRGB:       true,
  processMonochrome:true,
  combineRGB: true,
  ai: { deblur1:true, deblur2:true, stretch:true, denoise:true, starless:true, runGradientCorrection: false, runGraxpert: false },
  colorEnhanceRGBStarsStretched: true,
  spccGraphs: false,
  save: {
    rgb: { final_stretched: false, final_linear: false, stars_stretched: true, starless_stretched: false, starless_linear: false, integration_linear: false, baseline_linear: false, deblur1: false, deblur2: false, denoised: false },
    mono: { final_stretched: false, final_linear: false, stars_stretched: false, starless_stretched: true, starless_linear: false, integration_linear: false, baseline_linear: false, deblur1: false, deblur2: false, denoised: false }
  }
};

// -------------------- Utility Functions --------------------
function ensureDir(p){ if(!File.directoryExists(p)) File.createDirectory(p); }
function tsFolder(base){
  function p2(n){ return n<10?"0"+n:""+n; }
  var d=new Date();
  var ts=d.getFullYear()+"-"+p2(d.getMonth()+1)+"-"+p2(d.getDate())+"T"+p2(d.getHours())+"-"+p2(d.getMinutes())+"-"+p2(d.getSeconds());
  var out=base.replace(/\\/g,"/").replace(/\/$/,"")+"/Processed_"+ts;
  ensureDir(out); return out;
}
function closeAllWindowsExcept(ids){
  var wins=ImageWindow.windows;
  for(var i=wins.length-1;i>=0;--i){
    var keep=false;
    if(ids){ for(var j=0;j<ids.length;++j){ if(wins[i].mainView.id===ids[j]){ keep=true; break; } } }
    if(!keep){ try{ wins[i].forceClose(); }catch(_){ } }
  }
}
function sanitizeBase(name){ var b=name.replace(/[^\w\-]+/g,"_"); return b.length?b:"image"; }
function fwd(p){ return p.replace(/\\/g,"/"); }
function removeIf(path, keep){ try{ if(!keep && File.exists(path)) File.remove(path); }catch(_){} }
function shouldProcessConfig(cfg){
  return !!( cfg.final_stretched || cfg.final_linear || cfg.stars_stretched || cfg.starless_stretched || cfg.starless_linear || cfg.integration_linear || cfg.baseline_linear || cfg.deblur1 || cfg.deblur2 || cfg.denoised );
}
function wait(ms) {
    var start = Date.now();
    var end = start + ms;
    while (Date.now() < end) {
        processEvents(); // Keep PixInsight responsive
    }
}

/*
 * PIXINSIGHT BATCH CONVERTER ALGORITHM - EXTRACTED FROM BatchFormatConversion.js
 */
function writeImageUsingPIAlgorithm(image, outputFilePath, bitsPerSample, floatSample) {
    let outputFormat = new FileFormat(".tif", false/*toRead*/, true/*toWrite*/);
    if (outputFormat.isNull)
        throw new Error("No installed file format can write TIFF files.");

    let f = new FileFormatInstance(outputFormat);
    if (f.isNull)
        throw new Error("Unable to instantiate TIFF file format.");

    if (!f.create(outputFilePath, "" /* no output hints for TIFF */))
        throw new Error("Error creating output file: " + outputFilePath);

    let d = new ImageDescription;
    d.width = image.width;
    d.height = image.height;
    d.numberOfChannels = image.numberOfChannels;
    d.colorSpace = image.colorSpace;
    d.bitsPerSample = bitsPerSample || 16;
    d.ieeefpSampleFormat = floatSample || false;

    if (!f.setOptions(d))
        throw new Error("Unable to set output file options: " + outputFilePath);

    if (!f.writeImage(image))
        throw new Error("Error writing output file: " + outputFilePath);

    f.close();
}

/*
 * CORRECTED TIFF SAVE FUNCTION - Using PixInsight's BatchFormatConversion Algorithm
 */
function saveAs16BitTiff_Photoshop(win, path) {
    if (!win || !win.isWindow) {
        Console.writeln("Error: Invalid ImageWindow provided.");
        return;
    }

    var tifPath = path + ".tif";
    var originalView = win.mainView;

    Console.writeln("Starting TIFF export using PixInsight BatchFormatConversion algorithm...");

    try {
        let bitsPerSample = 16;
        let floatSample = false;

        let image = new Image(originalView.image.width,
                             originalView.image.height,
                             originalView.image.numberOfChannels,
                             originalView.image.colorSpace,
                             bitsPerSample,
                             floatSample ? SampleType_Real : SampleType_Integer);

        image.assign(originalView.image);

        writeImageUsingPIAlgorithm(image, tifPath, bitsPerSample, floatSample);
        Console.writeln("✅ Successfully saved TIFF using PixInsight algorithm: " + tifPath);
        image.free();

    } catch (e) {
        Console.writeln("⚠️ Error during TIFF conversion: " + e.message);
        throw e;
    }
}

// -------------------- Debug and Revert Functions --------------------
function debugSave(win, stepName, baseTag, debugDir) {
    if (!DEBUG_MODE) return;
    if (!win || !win.isWindow) {
        Console.writeln("Debug Save Warning: Invalid window provided for step '", stepName, "'");
        return;
    }

    let counterStr = debugStepCounter < 10 ? "0" + debugStepCounter : "" + debugStepCounter;
    let sanitizedStepName = stepName.replace(/[^\w\-]+/g, "_");
    let stepFolder = debugDir + "/" + counterStr + "_" + sanitizedStepName;

    try {
        if (!File.directoryExists(stepFolder)) {
            File.createDirectory(stepFolder, true);
        }
    } catch(e) {
        Console.writeln("Debug Save Warning: Could not create step folder: " + stepFolder);
        stepFolder = debugDir;
    }

    let baseFileName = counterStr + "_" + baseTag + "_" + sanitizedStepName;
    let xisfPath = stepFolder + "/" + baseFileName + ".xisf";

    try {
        win.saveAs(xisfPath, false, false, false, false);
        Console.writeln("DEBUG: Saved XISF: " + xisfPath);
    } catch(e) {
        Console.writeln("DEBUG: Failed to save XISF: " + e.message);
    }

    debugStepCounter++;
}

// -------------------- Interactive Review Functions --------------------
function showStretchedPreview(win) {
    if (!win || !win.isWindow) return false;

    Console.writeln("📺 Applying auto-stretch for visual review...");

    try {
        win.show();
        win.bringToFront();
        win.zoomToFit();

        var view = win.mainView;
        var median = view.computeOrFetchProperty("Median");
        var mad = view.computeOrFetchProperty("MAD");
        var stf = new ScreenTransferFunction;
        var n = view.image.isColor ? 3 : 1;
        var stfParams = [
            [0, 1, 0.5, 0, 1], [0, 1, 0.5, 0, 1], [0, 1, 0.5, 0, 1], [0, 1, 0.5, 0, 1]
        ];

        for (var c = 0; c < n; ++c) {
            var med = median.at(c);
            var madVal = mad.at(c) * 1.4826;
            var c0 = Math.max(0, med - 2.8 * madVal);
            var m = Math.mtf(0.25, med - c0);
            stfParams[c] = [c0, 1.0, m, 0, 1];
        }

        stf.STF = stfParams;
        stf.executeOn(view);
        win.show();
        win.bringToFront();
        Console.writeln("✅ Auto-stretch applied for review");
        return true;
    } catch(e) {
        Console.writeln("❌ Auto-stretch failed: " + e.message);
        return false;
    }
}

function resetStretch(win) {
    if (!win || !win.isWindow) return false;

    try {
        if (typeof win.disableScreenTransferFunctions === 'function') {
            win.disableScreenTransferFunctions();
        } else {
            var stf = new ScreenTransferFunction;
            var identitySTF = [
                [0, 1, 0.5, 0, 1], [0, 1, 0.5, 0, 1],
                [0, 1, 0.5, 0, 1], [0, 1, 0.5, 0, 1]
            ];
            stf.STF = identitySTF;
            stf.executeOn(win.mainView);
        }
        Console.writeln("✅ Reset to linear view");
        return true;
    } catch(e) {
        Console.writeln("⚠️ Reset failed: " + e.message + " (continuing anyway)");
        return true;
    }
}

// Simple, non-reversible pause function for debugging.
function pauseForView(win, stepName) {
    if (!win || !win.isWindow) {
        Console.writeln("Pause for View Warning: Invalid window for step '" + stepName + "'");
        return;
    }

    Console.writeln("\n👀 PAUSING TO VIEW: " + stepName);
    showStretchedPreview(win);

    (new MessageBox(
        "Pausing to view the result after: " + stepName + ".\n\n" +
        "The image is auto-stretched for viewing purposes only.\n\n" +
        "Click OK to continue processing.",
        "Debug Viewpoint",
        StdIcon_Information,
        StdButton_Ok
    )).execute();

    resetStretch(win);
    Console.writeln("✅ Continuing processing...");
}

// -------------------- File System Functions --------------------
function findAllInputImages(dir){
  if(!File.directoryExists(dir)) throw new Error("Input directory does not exist: "+dir);
  var v=[];
  var ff=new FileFind;
  var supportedExtensions = [".xisf", ".fit", ".fits", ".tif", ".tiff"];
  if(ff.begin(dir+"/*.*")){
    do {
      var nameLower = ff.name.toLowerCase();
      for (var i = 0; i < supportedExtensions.length; ++i) {
        if (nameLower.endsWith(supportedExtensions[i])) {
          v.push(dir+"/"+ff.name);
          break;
        }
      }
    } while(ff.next());
  }
  return v;
}
function detectFilterFromName(fileName) {
  var s = fileName.toLowerCase();
  if (s.indexOf("filter-red")>=0 || /filter-r(?![a-z])/.test(s) || /\bred\b/.test(s)) return "R";
  if (s.indexOf("filter-green")>=0 || /filter-g(?![a-z])/.test(s) || /\bgreen\b/.test(s)) return "G";
  if (s.indexOf("filter-blue")>=0 || /filter-b(?![a-z])/.test(s) || /\bblue\b/.test(s)) return "B";
  if (/luminance|filter-l(?![a-z])|\bl\b/.test(s)) return "L";
  if (/ha|h\-?alpha|h_?a/.test(s)) return "Ha";
  if (/oiii|o3|o\-?iii/.test(s)) return "OIII";
  if (/sii|s2|s\-?ii/.test(s)) return "SII";
  return null;
}
function buildWorkPlan(dir, combineRGB){
  var files = findAllInputImages(dir);
  var byFilter = {}, unknownSingles = [];
  for (var i=0;i<files.length;++i){
    var name = File.extractName(files[i]);
    var f = detectFilterFromName(name);
    if (f){ if (!byFilter[f]) byFilter[f]=[]; byFilter[f].push(files[i]); }
    else { unknownSingles.push(files[i]); }
  }
  function pickFirst(arr){ if(!arr||!arr.length) return null; arr.sort(); return arr[0]; }
  var haveR=!!(byFilter.R&&byFilter.R.length), haveG=!!(byFilter.G&&byFilter.G.length), haveB=!!(byFilter.B&&byFilter.B.length);
  var plan={ doRGB:false, r:null, g:null, b:null, singles:[] };
  if (combineRGB && haveR && haveG && haveB){
    plan.doRGB=true; plan.r=pickFirst(byFilter.R); plan.g=pickFirst(byFilter.G); plan.b=pickFirst(byFilter.B);
  }
  function pushSingles(k){
    if(byFilter[k]) for(var i=0;i<byFilter[k].length;++i){
      var p=byFilter[k][i];
      if (plan.doRGB && ((k==="R"&&p===plan.r)||(k==="G"&&p===plan.g)||(k==="B"&&p===plan.b))) continue;
      plan.singles.push({ path:p, tag:k, isStackedRGB: false });
    }
  }
  ["L","Ha","OIII","SII"].forEach(pushSingles);
  if(!plan.doRGB) ["R","G","B"].forEach(pushSingles);
  for (var k=0;k<unknownSingles.length;++k) {
    var filePath = unknownSingles[k];
    var isColorStack = false;
    try {
        var tempWinArr = ImageWindow.open(filePath);
        if (tempWinArr.length > 0) {
            var tempWin = tempWinArr[0];
            if (tempWin.mainView.image.isColor) isColorStack = true;
            tempWin.forceClose();
        }
    } catch (e) {
        Console.writeln("Warning: Could not determine color space for " + File.extractName(filePath) + ". Assuming Mono.");
    }
    plan.singles.push({ path: filePath, tag: isColorStack ? "Color" : "Single", isStackedRGB: isColorStack });
  }
  return plan;
}

// -------------------- Processing Functions (Robust Pattern) --------------------
function handleRobustExecution(win, stepName, sum, sumKey, executionFunc, baseTag, debugDir) {
    if (!win || !win.isWindow) {
        Console.criticalln("❌ CRITICAL: Invalid window passed to " + stepName + ". Aborting image.");
        throw new Error(ABORT_PROCESSING_IMAGE);
    }

    try {
        Console.writeln("\n=== Running " + stepName + " ===");

        var details = executionFunc(win);
        sum[sumKey] = {name: stepName, status: "✅", details: details || "Applied successfully"};
        debugSave(win, "After_" + stepName.replace(/[\s\(\)]+/g, '_'), baseTag, debugDir);

        return win;

    } catch (e) {
        if (e.message === ABORT_PROCESSING || e.message === ABORT_PROCESSING_IMAGE) throw e;
        Console.writeln("❌ " + stepName + " FAILED: " + e.message);
        sum[sumKey] = {name: stepName, status: "❌", details: "Failed. Error: " + e.message};
        throw new Error(ABORT_PROCESSING_IMAGE); // Stop processing this image on any failure.
    }
}

function finalABE(win, sum, baseTag, debugDir){
  return handleRobustExecution(win, "ABE (Background Extraction)", sum, "backgroundExtraction", function(w) {

    // Snapshot existing windows before ABE
    var beforeIds = [];
    var ws = ImageWindow.windows;
    for (var i = 0; i < ws.length; ++i) beforeIds.push(ws[i].mainView.id);

    // Run ABE (model discarded, target replaced)
    var P = new AutomaticBackgroundExtractor;
    P.tolerance = 1.000; P.deviation = 0.800; P.unbalance = 1.800; P.minBoxFraction = 0.050;
    P.polyDegree = 4; P.boxSize = 5; P.boxSeparation = 5;
    P.targetCorrection = 0;          // Subtraction
    P.normalize = true;
    P.replaceTarget = true;          // Modify current image
    P.discardModel = true;           // Do not keep background model window
    P.executeOn(w.mainView);

    // Close any NEW windows ABE might have spawned (defensive)
    var after = ImageWindow.windows;
    for (var i = 0; i < after.length; ++i) {
      var id = after[i].mainView.id, known = false;
      for (var j = 0; j < beforeIds.length; ++j) { if (beforeIds[j] === id) { known = true; break; } }
      if (!known && id !== w.mainView.id) { try { after[i].forceClose(); } catch(_){} }
    }

    // Ensure the processed view is visible (apply STF for display only)
    try {
      var stf = STFAutoStretch(w.mainView, -2.80, 0.25, w.mainView.image.isColor);
      var s = new ScreenTransferFunction; s.STF = stf.STF; s.executeOn(w.mainView);
      w.show(); w.bringToFront(); w.zoomToFit();
    } catch(_){}

    return "ABE Subtraction applied";
  }, baseTag, debugDir);
}

function runGradientCorrection(win, sum, baseTag, debugDir) {
    return handleRobustExecution(win, "GradientCorrection", sum, "gradientCorrection", function(w) {
        var P = new GradientCorrection;
        P.reference = 0.50;
        P.lowThreshold = 0.20;
        P.lowTolerance = 0.50;
        P.highThreshold = 0.05;
        P.highTolerance = 0.00;
        P.iterations = 15;
        P.scale = 7.60;
        P.smoothness = 0.71;
        P.downsamplingFactor = 16;
        P.protection = true;
        P.protectionThreshold = 0.10;
        P.protectionAmount = 0.50;
        P.protectionSmoothingFactor = 16;
        P.lowClippingLevel = 0.000076;
        P.automaticConvergence = true;
        P.convergenceLimit = 0.00001000;
        P.maxIterations = 10;
        P.useSimplification = true;
        P.simplificationDegree = 1;
        P.simplificationScale = 1024;
        P.generateSimpleModel = false;
        P.generateGradientModel = false;
        P.generateProtectionMasks = false;
        P.gridSamplingDelta = 16;
        P.executeOn(w.mainView);
        return "Applied with custom settings";
    }, baseTag, debugDir);
}

function runGraXpert(win, sum, baseTag, debugDir) {
    return handleRobustExecution(win, "GraXpert", sum, "graxpert", function(w) {
        let gxp = new GraXpertLib;
        gxp.graxpertParameters.correction = 0;
        gxp.graxpertParameters.smoothing = 0.964;
        gxp.graxpertParameters.replaceTarget = true;
        gxp.graxpertParameters.showBackground = false;
        gxp.graxpertParameters.targetView = w.mainView;
        gxp.process();
        return "Applied via library call";
    }, baseTag, debugDir);
}

function autoBlackPoint(win, sum, baseTag, debugDir){
    return handleRobustExecution(win, "Black Point Adjustment", sum, "blackPoint", function(w) {
        var img = w.mainView.image;
        var details = "";

        if (!img.readSamples) {
            var AH_fallback = new AutoHistogram();
            AH_fallback.auto=true; AH_fallback.clipLow=0.1; AH_fallback.clipHigh=0.1;
            AH_fallback.executeOn(w.mainView);
            details = "Fallback AutoHistogram (No sample access)";
        } else if(!img.isColor || img.numberOfChannels<3){
            var AH=new AutoHistogram();
            AH.auto=true; AH.clipLow=0.1; AH.clipHigh=0.1;
            AH.executeOn(w.mainView);
            details = "AutoHistogram (Mono/NB)";
        } else {
            var width=img.width, height=img.height, sampleSize=20, numSamples=20;
            var rs=[],gs=[],bs=[];
            for(var i=0;i<numSamples;++i){
              var x=Math.floor(Math.random()*(width-sampleSize)), y=Math.floor(Math.random()*(height-sampleSize));
              var rect=new Rect(x,y,x+sampleSize,y+sampleSize), s=img.readSamples(rect), cnt=sampleSize*sampleSize, r=0,g=0,b=0;
              for(var p=0;p<cnt;++p){ r+=s[p*3]; g+=s[p*3+1]; b+=s[p*3+2]; }
              rs.push(r/cnt); gs.push(g/cnt); bs.push(b/cnt);
            }
            rs.sort(function(a,b){return a-b;}); gs.sort(function(a,b){return a-b;}); bs.sort(function(a,b){return a-b;});
            var n=Math.max(1,Math.floor(numSamples*0.25)), R=0,G=0,B=0;
            for(var m=0;m<n;++m){ R+=rs[m]; G+=gs[m]; B+=bs[m]; }
            R/=n; G/=n; B/=n;

            try{
              var L=new Levels();
              L.redBlack=Math.min(R*0.8,0.02);
              L.greenBlack=Math.min(G*0.9,0.03);
              L.blueBlack=Math.min(B*0.8,0.02);
              L.redWhite=0.98;
              L.greenWhite=0.97;
              L.blueWhite=0.98;
              L.executeOn(w.mainView);
              details = "Levels (Sampled)";
            }catch(e2){
              var AH2=new AutoHistogram();
              AH2.auto=true; AH2.clipLow=0.1; AH2.clipHigh=0.1;
              AH2.executeOn(w.mainView);
              details = "Fallback AutoHistogram (Color)";
            }
        }
        return details;
    }, baseTag, debugDir);
}

// -------------------- AI steps --------------------
function deblur1(win, sum, baseTag, debugDir){
    return handleRobustExecution(win, "Deblur V1 (Round Stars)", sum, "deblurV1", function(w) {
        var P=new BlurXTerminator();
        P.sharpenStars=0.00; P.adjustStarHalos=0.00; P.psfDiameter=0.00; P.sharpenNonstellar=0.00;
        P.autoPSF=true; P.correctOnly=true; P.correctFirst=false; P.nonstellarThenStellar=false; P.luminanceOnly=false;
        P.executeOn(w.mainView);
        return "Round stars correction applied";
    }, baseTag, debugDir);
}

function deblur2(win, sum, baseTag, debugDir){
    return handleRobustExecution(win, "Deblur V2 (Enhance)", sum, "deblurV2", function(w) {
        var P=new BlurXTerminator();
        P.sharpenStars=0.25; P.adjustStarHalos=0.00; P.psfDiameter=0.00; P.sharpenNonstellar=0.90;
        P.autoPSF=true; P.correctOnly=false; P.correctFirst=false; P.nonstellarThenStellar=false; P.luminanceOnly=false;
        P.executeOn(w.mainView);
        return "Enhancement applied";
    }, baseTag, debugDir);
}

function denoise(win, sum, baseTag, debugDir){
    return handleRobustExecution(win, "Denoising (NoiseX)", sum, "denoising", function(w) {
        var P=new NoiseXTerminator();
        P.intensityColorSeparation=false;
        P.frequencySeparation=false;
        P.denoise=0.90;
        P.iterations=2;
        P.detail = 0.15;
        P.executeOn(w.mainView);
        return "Denoising applied (0.90, Detail 0.15)";
    }, baseTag, debugDir);
}

// -------------------- ImageSolver + SPCC (Standard Pattern) --------------------
function solveImage(win, sum, baseTag, debugDir){
  try{
    Console.writeln("\n=== ImageSolver (for SPCC) ===");
    var solver = new ImageSolver();
    solver.Init(win, false);
    solver.useMetadata = true;
    solver.catalog = "GAIA DR3";
    solver.useDistortionCorrection = false;
    solver.generateErrorMaps = false;
    solver.showStars = false;
    solver.showDistortion = false;
    solver.generateDistortionMaps = false;
    solver.sensitivity = 0.1;

    if (!solver.SolveImage(win)){
      Console.writeln("  ⚠️ Metadata-based solving failed, trying blind...");
      solver.useMetadata = false;
      if (!solver.SolveImage(win)) throw new Error("Plate solution not found.");
    }
    sum.solver={name:"ImageSolver",status:"✅",details:"Solved (GAIA DR3)"};
    debugSave(win, "After_ImageSolver", baseTag, debugDir);
    return true;
  }catch(e){
    sum.solver={name:"ImageSolver",status:"❌",details:e.message};
    return false;
  }
}

function performSPCC(win, sum, profileSelector, showGraphs, baseTag, debugDir){
  try{
    Console.writeln("\n=== SPCC (using fresh WCS) — profile: "+profileSelector+" ===");
    var P=new SpectrophotometricColorCalibration();
    try{ P.whiteReferenceId = "Average Spiral Galaxy"; }catch(_){ try{ P.whiteReferenceId="AVG_G2V"; }catch(_){ } }
    try{ P.qeCurve = "Sony IMX411/455/461/533/571"; }catch(_){}
    try{
      if(profileSelector==="RGB"){
        P.redFilter   = "Astronomik Typ 2c R";
        P.greenFilter = "Astronomik Typ 2c G";
        P.blueFilter  = "Astronomik Typ 2c B";
      }else{
        P.redFilter   = "Sony Color Sensor R";
        P.greenFilter = "Sony Color Sensor G";
        P.blueFilter  = "Sony Color Sensor B";
      }
    }catch(_){}
    try{ P.narrowbandMode=false; }catch(_){}
    try{ P.generateGraphs=showGraphs||false; }catch(_){}
    try{ P.applyCalibration=true; }catch(_){}
    try{ P.catalog="Gaia DR3/SP"; }catch(_){}
    try{ P.backgroundNeutralization = true; P.lowerLimit = -2.80; P.upperLimit = +2.00; }catch(_){}

    P.executeOn(win.mainView);
    sum.spcc={name:"SPCC",status:"✅",details:"Applied"};
    debugSave(win, "After_SPCC", baseTag, debugDir);
    return true;
  }catch(e){ sum.spcc={name:"SPCC",status:"❌",details:e.message}; return false; }
}

// -------------------- Stretch Functions --------------------
function STFAutoStretch( view, shadowsClipping, targetBackground, rgbLinked )
{
    if (shadowsClipping === undefined) shadowsClipping = -2.80;
    if (targetBackground === undefined) targetBackground = 0.25;
    if (rgbLinked === undefined) rgbLinked = true;

    var stf = new ScreenTransferFunction;
    var n = view.image.isColor ? 3 : 1;
    var median = new Vector( view.computeOrFetchProperty( "Median" ) );
    var mad = new Vector( view.computeOrFetchProperty( "MAD" ) );
    mad.mul( 1.4826 );

    if ( rgbLinked && n > 1)
    {
      var invertedChannels = 0;
      for ( var c = 0; c < n; ++c ) if ( median.at( c ) > 0.5 ) ++invertedChannels;
      if ( invertedChannels < n ) {
        var c0_sum = 0, median_sum = 0;
        for ( var c = 0; c < n; ++c ) {
          if ( 1 + mad.at( c ) != 1 ) c0_sum += median.at( c ) + shadowsClipping * mad.at( c );
          median_sum += median.at( c );
        }
        var c0 = Math.range( c0_sum/n, 0.0, 1.0 );
        var m = Math.mtf( targetBackground, median_sum/n - c0 );
        stf.STF = [ [c0, 1, m, 0, 1], [c0, 1, m, 0, 1], [c0, 1, m, 0, 1], [0, 1, 0.5, 0, 1] ];
      } else {
        var c1_sum = 0, median_sum = 0;
        for ( var c = 0; c < n; ++c ) {
          if ( 1 + mad.at( c ) != 1 ) c1_sum += median.at( c ) - shadowsClipping * mad.at( c );
          median_sum += median.at( c );
        }
        var c1 = Math.range( c1_sum/n, 0.0, 1.0 );
        var m = Math.mtf( c1 - median_sum/n, targetBackground );
        stf.STF = [ [0, c1, m, 0, 1], [0, c1, m, 0, 1], [0, c1, m, 0, 1], [0, 1, 0.5, 0, 1] ];
      }
    } else {
      var A = [ [0, 1, 0.5, 0, 1], [0, 1, 0.5, 0, 1], [0, 1, 0.5, 0, 1], [0, 1, 0.5, 0, 1] ];
      for ( var c = 0; c < n; ++c ) {
        if ( median.at( c ) < 0.5 ) {
          var c0 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) + shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 0.0;
          var m = Math.mtf( targetBackground, median.at( c ) - c0 );
          A[c] = [c0, 1, m, 0, 1];
        } else {
          var c1 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) - shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 1.0;
          var m = Math.mtf( c1 - median.at( c ), targetBackground );
          A[c] = [0, c1, m, 0, 1];
        }
      }
      stf.STF = A;
    }
    return stf;
}

function ApplyHistogramTransformation( view, stf )
{
    var ht = new HistogramTransformation;
    var HT_IDENTITY = [0, 0.5, 1, 0, 1];
    var H = [ HT_IDENTITY.slice(), HT_IDENTITY.slice(), HT_IDENTITY.slice(), HT_IDENTITY.slice(), HT_IDENTITY.slice() ];
    var n = view.image.isColor ? 3 : 1;
    function mapSTFtoHT(stf_channel) { return [ stf_channel[0], stf_channel[2], stf_channel[1], stf_channel[3], stf_channel[4] ]; }

    if ( view.image.isColor ) {
        var linked = true;
        for(var c = 1; c < n; ++c) if(stf.STF[c][0] != stf.STF[0][0] || stf.STF[c][1] != stf.STF[0][1] || stf.STF[c][2] != stf.STF[0][2]) { linked = false; break; }
        if(linked) {
            H[3] = mapSTFtoHT(stf.STF[0]);
        } else {
            for ( var c = 0; c < n; ++c ) H[c] = mapSTFtoHT(stf.STF[c]);
        }
    } else {
        H[3] = mapSTFtoHT(stf.STF[0]);
    }
    ht.H = H;
    return ht.executeOn( view );
}

function applyPerfectNuclearStretch(view) {
    if (!view || !view.image || view.image.isNull) throw new Error("No active view for nuclear stretch.");
    var isColor = view.image.isColor;
    var rgbLinked = isColor;
    Console.writeln("Nuclear stretch: " + (isColor ? "RGB linked" : "Mono unlinked") + " mode");
    var stf = STFAutoStretch( view, -2.80, 0.25, rgbLinked );
    return ApplyHistogramTransformation( view, stf );
}

// -------------------- Color Enhance helpers --------------------
function applyColorEnhanceToView(view){
  var C = new CurvesTransformation;
  C.R = C.G = C.B = C.K = C.A = C.L = C.a = C.b = C.c = C.H = [[0.00000, 0.00000], [1.00000, 1.00000]];
  C.Rt = C.Gt = C.Bt = C.Kt = C.At = C.Lt = C.at = C.bt = C.ct = C.Ht = CurvesTransformation.prototype.AkimaSubsplines;
  C.S = [[0.00000, 0.00000], [0.14470, 0.33247], [1.00000, 1.00000]];
  C.St = CurvesTransformation.prototype.AkimaSubsplines;
  C.executeOn(view);
  var N = new SCNR;
  N.amount = 0.73;
  N.protectionMethod = SCNR.prototype.AverageNeutral;
  N.colorToRemove = SCNR.prototype.Green;
  N.preserveLightness = true;
  N.executeOn(view);
}

// -------------------- Main Processing Steps --------------------
function combineRGB(redPath, greenPath, bluePath, rootOut){
  Console.writeln("\n=== RGB Channel Combination ===");
  var r=ImageWindow.open(redPath), g=ImageWindow.open(greenPath), b=ImageWindow.open(bluePath);
  if(r.length===0||g.length===0||b.length===0) throw new Error("Failed to open one or more RGB masters");
  var CC=new ChannelCombination;
  CC.colorSpace=ChannelCombination.prototype.RGB;
  CC.channels=[[true,r[0].mainView.id],[true,g[0].mainView.id],[true,b[0].mainView.id]];
  CC.executeGlobal();
  var rgb=null, wins=ImageWindow.windows; for(var i=wins.length-1;i>=0;--i){ if(wins[i].mainView.image.isColor){ rgb=wins[i]; break; } }
  if(!rgb) throw new Error("Could not find RGB combined image");
  var stackDir=rootOut+"/5_stacked"; ensureDir(stackDir);
  var outPath=stackDir+"/RGB_Combined"+outputExtension;
  rgb.saveAs(outPath,false,false,false,false);
  try{ r[0].close(); }catch(_){}
  try{ g[0].close(); }catch(_){}
  try{ b[0].close(); }catch(_){}
  return {window:rgb, path:outPath, base:"RGB_Combined"};
}

function starSeparation(win, sum, finalDir, baseTag, saveCfg, isColor, enhanceRGBStarsStretched, debugDir) {
    try {
        Console.writeln("\n=== Running StarXTerminator ===");
        var tempDir = debugDir + "/temp";
        if (!File.directoryExists(tempDir)) File.createDirectory(tempDir, true);
        var tempOriginalPath = tempDir + "/temp_original_" + baseTag + "_" + Date.now() + ".xisf";
        win.saveAs(tempOriginalPath, false, false, false, false);

        var SX = new StarXTerminator();
        SX.generateStarImage = true;
        SX.unscreenStars = true;
        SX.largeOverlap = false;
        SX.executeOn(win.mainView);

        sum.starSeparation={name:"Star Separation",status:"✅",details:"StarX applied on stretched image"};
        debugSave(win, "After_StarSeparation_Starless", baseTag, debugDir);

        var starsWin = null;
        if (saveCfg.stars_stretched) {
            try {
                var originalWinArray = ImageWindow.open(tempOriginalPath);
                if (originalWinArray.length > 0) {
                    var originalWin = originalWinArray[0];
                    originalWin.mainView.id = "TempOriginal_" + Date.now();
                    var safeTagForId = baseTag.replace(/[^a-zA-Z0-9_]/g, '_');
                    if (safeTagForId.length > 60) safeTagForId = safeTagForId.substring(0, 60);
                    var starsId = "Stars_" + safeTagForId + "_" + Date.now();
                    var exprStars = "max(0, " + originalWin.mainView.id + " - " + win.mainView.id + ")";

                    var PM = new PixelMath();
                    PM.useSingleExpression = true; PM.expression = exprStars; PM.createNewImage = true;
                    PM.newImageId = starsId; PM.rescaleResult = false;
                    PM.executeOn(originalWin.mainView);
                    starsWin = ImageWindow.windowById(starsId);
                    if (!starsWin) Console.writeln("⚠️ Stars image creation failed.");
                    else Console.writeln("✅ Generated stars using PixelMath: Original - Starless");
                    try{ originalWin.forceClose(); }catch(_){}
                } else Console.writeln("⚠️ Could not reload original image for star generation");
            } catch(e) { Console.writeln("⚠️ Stars generation failed: " + e.message); }
        }

        if(saveCfg.starless_stretched) {
            saveAs16BitTiff_Photoshop(win, finalDir+"/Starless_Stretched_"+baseTag);
            Console.writeln("  Saved Starless (stretched): Starless_Stretched_" + baseTag + ".tif");
        }
        if(saveCfg.stars_stretched && starsWin){
            if(isColor && enhanceRGBStarsStretched) {
                Console.writeln("Applying color enhancement to stars...");
                applyColorEnhanceToView(starsWin.mainView);
                sum.starColorsEnhanced = {name:"Star colors enhanced", status:"✅", details:"S-curve and SCNR applied"};
            }
            saveAs16BitTiff_Photoshop(starsWin, finalDir+"/Stars_Stretched_"+baseTag);
            Console.writeln("  Saved Stars (stretched): Stars_Stretched_" + baseTag + ".tif");
        }
        try{ if (starsWin) starsWin.forceClose(); }catch(_){}
        try{ File.remove(tempOriginalPath); }catch(_){}
        return win;
    } catch(e) {
        if (e.message.startsWith("ABORT_")) throw e;
        Console.writeln("❌ Star Separation FAILED: " + e.message);
        sum.starSeparation={name:"Star Separation",status:"❌",details: "Failed. Error: " + e.message};
        throw new Error(ABORT_PROCESSING_IMAGE);
    }
}

function processOne(win, baseTag, rootOut, ai, saveCfg, isRGBCombined, enhanceRGBStarsStretched, isStackedRGB = false, spccGraphs = false, displayEachStep = false){
    var sum={};
    var stackDir=rootOut+"/5_stacked"; ensureDir(stackDir);
    var finalDir=rootOut+"/6_final";   ensureDir(finalDir);
    var shortTag = baseTag.length > 20 ? baseTag.substring(0, 20) : baseTag;
    var debugDir = rootOut + "/debug_" + shortTag;
    debugStepCounter = 1;
    if (DEBUG_MODE) ensureDir(debugDir);

    debugSave(win, "Initial_Integration", baseTag, debugDir);
    win.saveAs(stackDir+"/Integration_"+baseTag+outputExtension,false,false,false,false);
    sum.integrationSave={name:"Integration Save",status:"✅",details:"Integration saved"};
    closeAllWindowsExcept([win.mainView.id]);

    try {
        // --- LINEAR PROCESSING ---
        win = finalABE(win, sum, baseTag, debugDir);
        if(displayEachStep) pauseForView(win, "ABE (Background Extraction)");

        win = autoBlackPoint(win, sum, baseTag, debugDir);
        if(displayEachStep) pauseForView(win, "Black Point Adjustment (1)");

        if (ai.runGradientCorrection) {
            win = runGradientCorrection(win, sum, baseTag, debugDir);
            if(displayEachStep) pauseForView(win, "GradientCorrection");
        } else {
            sum.gradientCorrection = {name:"GradientCorrection", status:"⏭️", details:"Disabled by user choice"};
        }

        if (ai.runGraxpert) {
            win = runGraXpert(win, sum, baseTag, debugDir);
            if(displayEachStep) pauseForView(win, "GraXpert");
        } else {
            sum.graxpert = {name:"GraXpert", status:"⏭️", details:"Disabled by user choice"};
        }

        win = autoBlackPoint(win, sum, baseTag, debugDir);
        if(displayEachStep) pauseForView(win, "Black Point Adjustment (2)");

        if(ai.deblur1){
            win = deblur1(win, sum, baseTag, debugDir);
            if(displayEachStep) pauseForView(win, "Deblur V1 (Round Stars)");
        }

        var isColor = win.mainView.image.isColor;
        if (isColor) {
            if (solveImage(win, sum, baseTag, debugDir)) {
                if(displayEachStep) pauseForView(win, "Image Solver");
                performSPCC(win, sum, isRGBCombined ? "RGB" : "OSC", spccGraphs, baseTag, debugDir);
                if(displayEachStep) pauseForView(win, "SPCC");
            } else {
                sum.spcc = {name:"SPCC", status:"⏭️", details:"Skipped (no WCS)"};
            }
        } else {
            sum.solver = {name:"ImageSolver", status:"⏭️", details:"Skipped (mono/NB)"};
            sum.spcc = {name:"SPCC", status:"⏭️", details:"Skipped (mono/NB)"};
        }

        if(ai.deblur2){
            win = deblur2(win, sum, baseTag, debugDir);
            if(displayEachStep) pauseForView(win, "Deblur V2 (Enhance)");
        }

        win.saveAs(finalDir+"/Final_Stacked_"+baseTag+outputExtension,false,false,false,false);
        sum.baselineSave={name:"Baseline Save",status:"✅",details:"Baseline saved"};
        debugSave(win, "Baseline_Linear", baseTag, debugDir);
        if(displayEachStep) pauseForView(win, "Baseline Linear Save");

        // --- STRETCHED PROCESSING ---
        if(ai.stretch){
            Console.writeln("\n=== Applying Nuclear Stretch ===");
            applyPerfectNuclearStretch(win.mainView);
            win.saveAs(finalDir+"/Stretched_"+baseTag+outputExtension,false,false,false,false);
            debugSave(win, "After_Nuclear_Stretch", baseTag, debugDir);
            sum.stretch={name:"Nuclear Stretch",status:"✅",details:"Applied"};
            if(displayEachStep) pauseForView(win, "Nuclear Stretch");
        } else {
            sum.stretch={name:"Nuclear Stretch",status:"⏭️",details:"Disabled in settings"};
        }

        if(saveCfg.final_stretched && sum.stretch && sum.stretch.status === "✅") {
            saveAs16BitTiff_Photoshop(win, finalDir+"/Final_Stretched_"+baseTag);
        }

        if(ai.denoise){
            win = denoise(win, sum, baseTag, debugDir);
            if(displayEachStep) pauseForView(win, "Denoise");
        }

        if(ai.starless){
            if(saveCfg.stars_stretched || saveCfg.starless_stretched){
                win = starSeparation(win, sum, finalDir, baseTag, saveCfg, isColor, enhanceRGBStarsStretched, debugDir);
                if(displayEachStep) pauseForView(win, "Star Separation (Starless Image)");
            } else {
                sum.starSeparation={name:"Star Separation",status:"⏭️",details:"No star/starless outputs requested"};
            }
        }

    } catch (e) {
        if (e.message === ABORT_PROCESSING) throw e;
        Console.writeln("🛑 Processing stopped for '" + baseTag + "' due to error.");
    }
    return {win: win, summary: sum, baseTag: baseTag};
}

// -------------------- GUI --------------------
function showGUI(state){
  var dlg=new Dialog;
  dlg.windowTitle="Post-Integration Pipeline (RGB & Mono) - V12";
  dlg.sizer=new VerticalSizer;
  dlg.sizer.margin=10;
  dlg.sizer.spacing=8;

  var head=new Label(dlg);
  head.useRichText=true;
  head.text="<b>Utah Masterclass — Post-Integration Pipeline (V12)</b>";
  head.textAlignment=TextAlign_Center;
  dlg.sizer.add(head);

  var gTop=new GroupBox(dlg);
  gTop.title="General";
  gTop.sizer=new VerticalSizer;
  gTop.sizer.margin=8;
  gTop.sizer.spacing=6;

  var rowDisplay = new HorizontalSizer;
  rowDisplay.spacing = 6;
  var cbDisplaySteps = new CheckBox(dlg);
  cbDisplaySteps.text = "👀 Display each step (for debugging)";
  cbDisplaySteps.checked = state.displayEachStep;
  cbDisplaySteps.toolTip = "If checked, the script will pause after every processing step to show the result.";
  rowDisplay.add(cbDisplaySteps);
  rowDisplay.addStretch();
  gTop.sizer.add(rowDisplay);

  var rowIn=new HorizontalSizer;
  rowIn.spacing=6;
  var labelIn=new Label(dlg);
  labelIn.text="Input Directory:";
  labelIn.textAlignment=TextAlign_Right|TextAlign_VertCenter;
  var editIn=new Edit(dlg);
  editIn.readOnly=true;
  editIn.minWidth=560;
  editIn.text=state.inputDir;
  var btnIn=new PushButton(dlg);
  btnIn.text="Browse...";
  btnIn.icon=dlg.scaledResource(":/icons/select-file.png");
  btnIn.onClick=function(){
    var d=new GetDirectoryDialog;
    d.caption="Select Input Directory";
    if(d.execute()){ editIn.text=fwd(d.directory).replace(/\/$/,""); }
  };
  rowIn.add(labelIn);
  rowIn.add(editIn,100);
  rowIn.add(btnIn);
  gTop.sizer.add(rowIn);

  var rowOut=new HorizontalSizer;
  rowOut.spacing=6;
  var labelOut=new Label(dlg);
  labelOut.text="Output Directory:";
  labelOut.textAlignment=TextAlign_Right|TextAlign_VertCenter;
  var editOut=new Edit(dlg);
  editOut.readOnly=true;
  editOut.minWidth=560;
  editOut.text=state.outputDir;
  var btnOut=new PushButton(dlg);
  btnOut.text="Browse...";
  btnOut.icon=dlg.scaledResource(":/icons/select-file.png");
  btnOut.onClick=function(){
    var d=new GetDirectoryDialog;
    d.caption="Select Output Base Directory";
    if(d.execute()){ editOut.text=fwd(d.directory).replace(/\/$/,""); }
  };
  rowOut.add(labelOut);
  rowOut.add(editOut,100);
  rowOut.add(btnOut);
  gTop.sizer.add(rowOut);
  dlg.sizer.add(gTop);

  var gAI=new GroupBox(dlg);
  gAI.title="AI / Processing Steps";
  gAI.sizer=new VerticalSizer;
  gAI.sizer.margin=8;
  gAI.sizer.spacing=6;

  var rowAI1=new HorizontalSizer;
  rowAI1.spacing=12;
  var cbD1=new CheckBox(dlg);
  cbD1.text="✨ Deblur V1 (round stars)";
  cbD1.checked=state.ai.deblur1;
  var cbD2=new CheckBox(dlg);
  cbD2.text="✨ Deblur V2 (enhance)";
  cbD2.checked=state.ai.deblur2;
  var cbST=new CheckBox(dlg);
  cbST.text="🌀 Stretch (AutoSTF→HT)";
  cbST.checked=state.ai.stretch;
  var cbDN=new CheckBox(dlg);
  cbDN.text="🧼 Denoise";
  cbDN.checked=state.ai.denoise;
  var cbSL=new CheckBox(dlg);
  cbSL.text="✂️ Enable StarX (for starless/stars)";
  cbSL.checked=state.ai.starless;
  rowAI1.add(cbD1); rowAI1.add(cbD2); rowAI1.add(cbST); rowAI1.add(cbDN); rowAI1.add(cbSL);
  rowAI1.addStretch();
  gAI.sizer.add(rowAI1);

  var rowAI2=new HorizontalSizer;
  rowAI2.spacing=12;
  var cbSPCCGraph=new CheckBox(dlg);
  cbSPCCGraph.text="📊 Show SPCC Graphs (Advanced)";
  cbSPCCGraph.checked=state.spccGraphs;
  rowAI2.add(cbSPCCGraph);
  rowAI2.addStretch();
  gAI.sizer.add(rowAI2);
  dlg.sizer.add(gAI);

  var gGrad = new GroupBox(dlg);
  gGrad.title = "Gradient Correction";
  gGrad.sizer = new VerticalSizer;
  gGrad.sizer.margin = 8;
  gGrad.sizer.spacing = 6;
  var rowGrad = new HorizontalSizer;
  rowGrad.spacing = 12;
  var cbGC = new CheckBox(gGrad);
  cbGC.text = "GradientCorrection";
  cbGC.checked = state.ai.runGradientCorrection;
  var cbGraX = new CheckBox(gGrad);
  cbGraX.text = "GraXpert";
  cbGraX.checked = state.ai.runGraxpert;
  rowGrad.add(cbGC); rowGrad.add(cbGraX);
  rowGrad.addStretch();
  gGrad.sizer.add(rowGrad);
  dlg.sizer.add(gGrad);

  var gRGB=new GroupBox(dlg);
  gRGB.title="RGB Outputs";
  gRGB.sizer=new VerticalSizer;
  gRGB.sizer.margin=8;
  gRGB.sizer.spacing=6;
  var chkProcRGB=new CheckBox(gRGB);
  chkProcRGB.text="✅ Process RGB / Color";
  chkProcRGB.checked=state.processRGB;
  gRGB.sizer.add(chkProcRGB);
  var cbCombine=new CheckBox(dlg);
  cbCombine.text="Auto-detect & combine R+G+B masters";
  cbCombine.checked=state.combineRGB;
  gRGB.sizer.add(cbCombine);
  var rowR1=new HorizontalSizer;
  rowR1.spacing=10;
  var lR1=new Label(dlg); lR1.text="🏆 Finals:"; lR1.minWidth=120;
  var rFinalS=new CheckBox(dlg); rFinalS.text="Final (stretched, with stars) (TIFF)"; rFinalS.checked=state.save.rgb.final_stretched;
  var rFinalL=new CheckBox(dlg); rFinalL.text="Final (linear, with stars)"; rFinalL.checked=state.save.rgb.final_linear;
  rowR1.add(lR1); rowR1.add(rFinalS); rowR1.add(rFinalL); rowR1.addStretch();
  gRGB.sizer.add(rowR1);
  var rowR2=new HorizontalSizer;
  rowR2.spacing=10;
  var lR2=new Label(dlg); lR2.text="🎭 Masks & Starless:"; lR2.minWidth=120;
  var rStarsS=new CheckBox(dlg); rStarsS.text="Stars (stretched mask) (TIFF)"; rStarsS.checked=state.save.rgb.stars_stretched;
  var rgbEnh=new CheckBox(dlg); rgbEnh.text="✨ Enhance with rich star colors"; rgbEnh.checked=state.colorEnhanceRGBStarsStretched;
  var rSLessS=new CheckBox(dlg); rSLessS.text="Starless (stretched) (TIFF)"; rSLessS.checked=state.save.rgb.starless_stretched;
  var rSLessL=new CheckBox(dlg); rSLessL.text="Starless (linear)"; rSLessL.checked=state.save.rgb.starless_linear;
  rowR2.add(lR2); rowR2.add(rStarsS); rowR2.add(rgbEnh); rowR2.add(rSLessS); rowR2.add(rSLessL); rowR2.addStretch();
  gRGB.sizer.add(rowR2);
  dlg.sizer.add(gRGB);

  var gM=new GroupBox(dlg);
  gM.title="Monochrome / Narrowband Outputs";
  gM.sizer=new VerticalSizer;
  gM.sizer.margin=8;
  gM.sizer.spacing=6;
  var chkProcMono=new CheckBox(gM); chkProcMono.text="✅ Process Monochrome / Singles"; chkProcMono.checked=state.processMonochrome;
  gM.sizer.add(chkProcMono);
  var rowM1=new HorizontalSizer; rowM1.spacing=10;
  var lM1=new Label(dlg); lM1.text="🏆 Finals:"; lM1.minWidth=120;
  var mFinalS=new CheckBox(dlg); mFinalS.text="Final (stretched, with stars) (TIFF)"; mFinalS.checked=state.save.mono.final_stretched;
  var mFinalL=new CheckBox(dlg); mFinalL.text="Final (linear, with stars)"; mFinalL.checked=state.save.mono.final_linear;
  rowM1.add(lM1); rowM1.add(mFinalS); rowM1.add(mFinalL); rowM1.addStretch();
  gM.sizer.add(rowM1);
  var rowM2=new HorizontalSizer; rowM2.spacing=10;
  var lM2=new Label(dlg); lM2.text="🎭 Starless & Masks:"; lM2.minWidth=120;
  var mStarsS=new CheckBox(dlg); mStarsS.text="Stars (stretched mask) (TIFF)"; mStarsS.checked=state.save.mono.stars_stretched;
  var mSLessS=new CheckBox(dlg); mSLessS.text="Starless (stretched) (TIFF)"; mSLessS.checked=state.save.mono.starless_stretched;
  var mSLessL=new CheckBox(dlg); mSLessL.text="Starless (linear)"; mSLessL.checked=state.save.mono.starless_linear;
  rowM2.add(lM2); rowM2.add(mStarsS); rowM2.add(mSLessS); rowM2.add(mSLessL); rowM2.addStretch();
  gM.sizer.add(rowM2);
  dlg.sizer.add(gM);

  var rgbControls=[cbCombine,rFinalS,rFinalL,rStarsS,rgbEnh,rSLessS,rSLessL];
  var monoControls=[mFinalS,mFinalL,mStarsS,mSLessS,mSLessL];
  function toggleSection(enabled,controls){ for(var i=0;i<controls.length;++i)controls[i].enabled=enabled; }
  chkProcRGB.onCheck=function(checked){ toggleSection(checked,rgbControls); };
  chkProcMono.onCheck=function(checked){ toggleSection(checked,monoControls); };
  toggleSection(chkProcRGB.checked,rgbControls);
  toggleSection(chkProcMono.checked,monoControls);

  var rowBtn=new HorizontalSizer; rowBtn.spacing=8;
  rowBtn.addStretch();
  var bStart=new PushButton(dlg); bStart.text="Start"; bStart.defaultButton=true;
  var bCancel=new PushButton(dlg); bCancel.text="Cancel";
  rowBtn.add(bStart); rowBtn.add(bCancel);
  dlg.sizer.add(rowBtn);

  bCancel.onClick=function(){dlg.cancel();};
  bStart.onClick=function(){
    state.inputDir=editIn.text; state.outputDir=editOut.text;
    if(!File.directoryExists(state.inputDir)){ (new MessageBox("Input directory does not exist.","Error",StdIcon_Error)).execute(); return; }
    if(!File.directoryExists(state.outputDir)){ (new MessageBox("Output directory does not exist.","Error",StdIcon_Error)).execute(); return; }
    state.displayEachStep = cbDisplaySteps.checked;
    state.processRGB=chkProcRGB.checked; state.processMonochrome=chkProcMono.checked; state.combineRGB=cbCombine.checked;
    state.ai.deblur1=cbD1.checked; state.ai.deblur2=cbD2.checked; state.ai.stretch=cbST.checked;
    state.ai.denoise=cbDN.checked; state.ai.starless=cbSL.checked;
    state.ai.runGradientCorrection = cbGC.checked; state.ai.runGraxpert = cbGraX.checked;
    state.colorEnhanceRGBStarsStretched=rgbEnh.checked; state.spccGraphs=cbSPCCGraph.checked;
    state.save.rgb={ final_stretched:rFinalS.checked, final_linear:rFinalL.checked, stars_stretched:rStarsS.checked, starless_stretched:rSLessS.checked, starless_linear:rSLessL.checked };
    state.save.mono={ final_stretched:mFinalS.checked, final_linear:mFinalL.checked, stars_stretched:mStarsS.checked, starless_stretched:mSLessS.checked, starless_linear:mSLessL.checked };
    dlg.ok();
  };
  return dlg.execute();
}

// -------------------- Entrypoint --------------------
function run(){
  Console.show();
  Console.writeln("=== Post-Integration Pipeline (RGB & Mono) — V12 ===");

  var settingsKey="PostIntegrationPipeline_V12";
  var state={
    displayEachStep: Settings.read(settingsKey+"/displayEachStep", DataType_Boolean) || defaults.displayEachStep,
    inputDir:Settings.read(settingsKey+"/InputDir",DataType_String)||defaults.inputDir,
    outputDir:Settings.read(settingsKey+"/OutputDir",DataType_String)||defaults.outputDir,
    processRGB:defaults.processRGB,
    processMonochrome:defaults.processMonochrome,
    combineRGB:defaults.combineRGB,
    ai:{
      deblur1:defaults.ai.deblur1, deblur2:defaults.ai.deblur2, stretch:defaults.ai.stretch,
      denoise:defaults.ai.denoise, starless:defaults.ai.starless,
      runGradientCorrection: Settings.read(settingsKey + "/runGradientCorrection", DataType_Boolean) || defaults.ai.runGradientCorrection,
      runGraxpert: Settings.read(settingsKey + "/runGraxpert", DataType_Boolean) || defaults.ai.runGraxpert
    },
    colorEnhanceRGBStarsStretched:defaults.colorEnhanceRGBStarsStretched,
    spccGraphs:defaults.spccGraphs,
    save:{ rgb:defaults.save.rgb, mono:defaults.save.mono }
  };

  if(!showGUI(state)){ Console.writeln("Cancelled."); return; }

  Settings.write(settingsKey+"/displayEachStep", DataType_Boolean, state.displayEachStep);
  Settings.write(settingsKey+"/InputDir",DataType_String,state.inputDir);
  Settings.write(settingsKey+"/OutputDir",DataType_String,state.outputDir);
  Settings.write(settingsKey + "/runGradientCorrection", DataType_Boolean, state.ai.runGradientCorrection);
  Settings.write(settingsKey + "/runGraxpert", DataType_Boolean, state.ai.runGraxpert);

  var root=tsFolder(state.outputDir);
  Console.writeln("Output folder: "+root);
  ensureDir(root+"/5_stacked");
  ensureDir(root+"/6_final");

  var allSummaries = [];
  try{
    var plan=buildWorkPlan(state.inputDir,state.combineRGB);
    var doRGB=state.processRGB&&plan.doRGB&&shouldProcessConfig(state.save.rgb);

    if(!state.processRGB&&!state.processMonochrome){
      Console.writeln("Both RGB and Monochrome processing are disabled. Exiting.");
      return;
    }

    if(doRGB){
      Console.writeln("\n→ Building RGB from: R, G, B masters");
      var combo=combineRGB(plan.r,plan.g,plan.b,root);
      if (state.displayEachStep) {
          pauseForView(combo.window, "RGB Combination");
      }
      var result = processOne(combo.window,combo.base,root,state.ai,state.save.rgb,true,state.colorEnhanceRGBStarsStretched,false,state.spccGraphs, state.displayEachStep);
      allSummaries.push({summary: result.summary, baseTag: result.baseTag});
      try{if (result.win && result.win.isWindow) result.win.forceClose();}catch(_){}
    }else{
      Console.writeln("RGB Combination: skipped.");
    }

    if(plan.singles.length>0){
      Console.writeln("\n→ Processing "+plan.singles.length+" single-channel master(s).");
      for(var i=0;i<plan.singles.length;++i){
        var singleInfo=plan.singles[i];
        Console.writeln("\n— ["+(i+1)+"/"+plan.singles.length+"] "+File.extractName(singleInfo.path)+"  ["+singleInfo.tag+"]");
        var w=ImageWindow.open(singleInfo.path);
        if(w.length===0){ Console.writeln("  ⚠️ Could not open, skipping."); continue; }
        var win=w[0],base=singleInfo.tag+"_"+sanitizeBase(File.extractName(singleInfo.path));
        var isColor=win.mainView.image.isColor;
        var saveCfg=isColor?state.save.rgb:state.save.mono;
        var procEnabled=isColor?state.processRGB:state.processMonochrome;
        if(!procEnabled||!shouldProcessConfig(saveCfg)){
          Console.writeln("  ⏭️ Skipped (processing/outputs disabled).");
          try{win.forceClose();}catch(_){}
          continue;
        }
        var result = processOne(win,base,root,state.ai,saveCfg,false,isColor&&state.colorEnhanceRGBStarsStretched,singleInfo.isStackedRGB,state.spccGraphs, state.displayEachStep);
        allSummaries.push({summary: result.summary, baseTag: result.baseTag});
        try{if (result.win && result.win.isWindow) result.win.forceClose();}catch(_){}
        closeAllWindowsExcept(null);
      }
    }else{
      Console.writeln("\nNo single channel masters found to process.");
    }

    Console.writeln("\n" + "=".repeat(80));
    Console.writeln("FINAL PROCESSING SUMMARY");
    Console.writeln("=".repeat(80));

    for(var s=0; s<allSummaries.length; s++){
      var summaryData = allSummaries[s];
      Console.writeln("\nSummary: " + summaryData.baseTag + " —");
      var order = ["backgroundExtraction", "gradientCorrection", "graxpert", "blackPoint", "solver", "spcc", "deblurV1", "deblurV2", "stretch", "denoising", "starSeparation", "starColorsEnhanced"];
      for(var j=0;j<order.length;++j){
        var k=order[j];
        if(summaryData.summary[k]){
          var it=summaryData.summary[k];
          Console.writeln("  "+it.status+" "+it.name+": "+it.details);
        }
      }
    }
    Console.writeln("\n=== Done. Output: "+root+" ===");
  }catch(err){
    if (err.message !== ABORT_PROCESSING) Console.criticalln("Error: "+err.message);
  }
}

run();
})(); // IIFE
